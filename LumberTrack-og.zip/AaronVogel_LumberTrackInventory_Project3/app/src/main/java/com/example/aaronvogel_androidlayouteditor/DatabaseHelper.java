package com.example.aaronvogel_androidlayouteditor;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Handles the local SQLite database for users and inventory items.
 * The database is persistent, so data remains after the app is closed.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "lumbertrack.db";
    private static final int DATABASE_VERSION = 1;

    public static final String USER_TABLE = "users";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    public static final String INVENTORY_TABLE = "inventory";
    public static final String ITEM_ID = "id";
    public static final String ITEM_NAME = "item_name";
    public static final String CATEGORY = "category";
    public static final String QUANTITY = "quantity";
    public static final String LOW_STOCK = "low_stock";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE " + USER_TABLE + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE NOT NULL, " +
                PASSWORD + " TEXT NOT NULL)";

        String createInventoryTable = "CREATE TABLE " + INVENTORY_TABLE + " (" +
                ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ITEM_NAME + " TEXT NOT NULL, " +
                CATEGORY + " TEXT NOT NULL, " +
                QUANTITY + " INTEGER NOT NULL, " +
                LOW_STOCK + " INTEGER NOT NULL)";

        db.execSQL(createUserTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE);
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(USER_TABLE, null, values);
        return result != -1;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                USER_TABLE,
                new String[]{USER_ID},
                USERNAME + " = ?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                USER_TABLE,
                new String[]{USER_ID},
                USERNAME + " = ? AND " + PASSWORD + " = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    public long addInventoryItem(String itemName, String category, int quantity, int lowStock) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, itemName);
        values.put(CATEGORY, category);
        values.put(QUANTITY, quantity);
        values.put(LOW_STOCK, lowStock);
        return db.insert(INVENTORY_TABLE, null, values);
    }

    public boolean updateInventoryItem(int itemId, String itemName, String category, int quantity, int lowStock) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, itemName);
        values.put(CATEGORY, category);
        values.put(QUANTITY, quantity);
        values.put(LOW_STOCK, lowStock);

        int rowsUpdated = db.update(
                INVENTORY_TABLE,
                values,
                ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );
        return rowsUpdated > 0;
    }

    public boolean deleteInventoryItem(int itemId) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(
                INVENTORY_TABLE,
                ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );
        return rowsDeleted > 0;
    }

    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                INVENTORY_TABLE,
                null,
                null,
                null,
                null,
                null,
                ITEM_NAME + " ASC"
        );
    }
}
