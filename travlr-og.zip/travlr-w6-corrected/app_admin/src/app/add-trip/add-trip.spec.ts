import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of } from 'rxjs';

import { AddTrip } from './add-trip';
import { TripData } from '../services/trip-data';

describe('AddTrip', () => {
  let component: AddTrip;
  let fixture: ComponentFixture<AddTrip>;

  const tripDataMock = {
    addTrip: vi.fn(() => of({}))
  };

  const routerMock = {
    navigate: vi.fn()
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddTrip],
      providers: [
        { provide: TripData, useValue: tripDataMock },
        { provide: Router, useValue: routerMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AddTrip);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should begin with an empty form', () => {
    expect(component.addForm.invalid).toBe(true);
  });
});
