import { Component, signal } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-add-trip',
  imports: [ReactiveFormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip {
  public addForm: FormGroup;
  submitted = false;

  errorMessage = signal('');
  successMessage = signal('');

  constructor(
    private formBuilder: FormBuilder,
    private tripData: TripData,
    private router: Router
  ) {
    this.addForm = this.formBuilder.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  get f() {
    return this.addForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;
    this.errorMessage.set('');
    this.successMessage.set('');

    if (this.addForm.invalid) {
      return;
    }

    const newTrip: Trip = {
      code: this.addForm.value.code,
      name: this.addForm.value.name,
      length: this.addForm.value.length,
      start: this.addForm.value.start,
      resort: this.addForm.value.resort,
      perPerson: this.addForm.value.perPerson,
      image: this.addForm.value.image,
      description: this.addForm.value.description
    };

    this.tripData.addTrip(newTrip).subscribe({
      next: () => {
        this.successMessage.set('Trip added successfully.');

        setTimeout(() => {
          this.router.navigate(['/']);
        }, 750);
      },
      error: (error) => {
        console.error('Unable to add trip:', error);

        this.errorMessage.set(
          error?.error?.message || 'Unable to add trip.'
        );
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/']);
  }
}