import { Component, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

import { Trip } from '../models/trip';
import { TripCard } from '../trip-card/trip-card';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-trip-listing',
  imports: [RouterLink, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit {
  trips = signal<Trip[]>([]);
  errorMessage = signal('');

  constructor(private tripData: TripData) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  private loadTrips(): void {
    this.tripData.getTrips().subscribe({
      next: (data: Trip[]) => {
        console.log('Trips received:', data);
        this.trips.set(data);
      },
      error: (error) => {
        console.error('Unable to retrieve trips:', error);
        this.errorMessage.set('Unable to load trips.');
      }
    });
  }
}
