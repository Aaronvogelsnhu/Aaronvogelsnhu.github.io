import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';

import { TripListing } from './trip-listing';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

describe('TripListing', () => {
  let component: TripListing;
  let fixture: ComponentFixture<TripListing>;

  const mockTrips: Trip[] = [
    {
      code: 'GALR210214',
      name: 'Gale Reef',
      length: '4 nights / 5 days',
      start: '2026-02-14',
      resort: 'Emerald Bay, 3 stars',
      perPerson: '799.00',
      image: 'reef1.jpg',
      description: 'Mock trip used for component testing.'
    }
  ];

  const tripDataMock = {
    getTrips: () => of(mockTrips)
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripListing],
      providers: [
        provideRouter([]),
        { provide: TripData, useValue: tripDataMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TripListing);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the Add Trip button', () => {
    const addButton: HTMLAnchorElement | null =
      fixture.nativeElement.querySelector('#addTrip');

    expect(addButton).toBeTruthy();
    expect(addButton?.textContent?.trim()).toBe('Add Trip');
    expect(addButton?.getAttribute('href')).toBe('/add-trip');
  });

  it('should display trips returned by the service', () => {
    expect(component.trips()).toEqual(mockTrips);
    expect(fixture.nativeElement.textContent).toContain('Gale Reef');
  });
});
