import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';

import { EditTrip } from './edit-trip';
import { TripData } from '../services/trip-data';

describe('EditTrip', () => {
  let component: EditTrip;
  let fixture: ComponentFixture<EditTrip>;

  const mockTrip = {
    code: 'GALR210214',
    name: 'Gale Reef',
    length: '4 nights / 5 days',
    start: '2026-02-14',
    resort: 'Emerald Bay, 3 stars',
    perPerson: '799.00',
    image: 'reef1.jpg',
    description: 'Mock trip used for component testing.'
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditTrip],
      providers: [
        {
          provide: TripData,
          useValue: {
            getTrip: () => of(mockTrip),
            updateTrip: () => of(mockTrip)
          }
        },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: { get: () => mockTrip.code }
            }
          }
        },
        { provide: Router, useValue: { navigate: vi.fn() } }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(EditTrip);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load mock trip data into the form', () => {
    expect(component.editForm.value.code).toBe(mockTrip.code);
    expect(component.editForm.value.name).toBe(mockTrip.name);
  });
});
