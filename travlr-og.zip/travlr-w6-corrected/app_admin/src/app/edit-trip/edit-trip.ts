import { Component, OnInit, signal } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  imports: [ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  public editForm: FormGroup;
  submitted = false;

  errorMessage = signal('');
  successMessage = signal('');
  loading = signal(true);

  private tripCode = '';

  constructor(
    private formBuilder: FormBuilder,
    private tripData: TripData,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.editForm = this.formBuilder.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.tripCode =
      this.route.snapshot.paramMap.get('tripCode') || '';

    if (!this.tripCode) {
      this.errorMessage.set('Trip code was not provided.');
      this.loading.set(false);
      return;
    }

    this.loadTrip();
  }

  get f() {
    return this.editForm.controls;
  }

  private loadTrip(): void {
    this.tripData.getTrip(this.tripCode).subscribe({
      next: (trip: Trip) => {
        const formattedDate =
          typeof trip.start === 'string'
            ? trip.start.substring(0, 10)
            : trip.start.toISOString().substring(0, 10);

        this.editForm.patchValue({
          code: trip.code,
          name: trip.name,
          length: trip.length,
          start: formattedDate,
          resort: trip.resort,
          perPerson: trip.perPerson,
          image: trip.image,
          description: trip.description
        });

        this.loading.set(false);
      },
      error: (error) => {
        console.error('Unable to retrieve trip:', error);
        this.errorMessage.set('Unable to load trip.');
        this.loading.set(false);
      }
    });
  }

  onSubmit(): void {
    this.submitted = true;
    this.errorMessage.set('');
    this.successMessage.set('');

    if (this.editForm.invalid) {
      return;
    }

    const updatedTrip: Trip = {
      code: this.editForm.value.code,
      name: this.editForm.value.name,
      length: this.editForm.value.length,
      start: this.editForm.value.start,
      resort: this.editForm.value.resort,
      perPerson: this.editForm.value.perPerson,
      image: this.editForm.value.image,
      description: this.editForm.value.description
    };

    this.tripData.updateTrip(updatedTrip).subscribe({
      next: () => {
        this.successMessage.set('Trip updated successfully.');

        setTimeout(() => {
          this.router.navigate(['/']);
        }, 750);
      },
      error: (error) => {
        console.error('Unable to update trip:', error);

        this.errorMessage.set(
          error?.error?.message || 'Unable to update trip.'
        );
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/']);
  }
}