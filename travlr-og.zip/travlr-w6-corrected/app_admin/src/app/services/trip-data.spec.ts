import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';

import { TripData } from './trip-data';

describe('TripData', () => {
  let service: TripData;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient()]
    });
    service = TestBed.inject(TripData);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
