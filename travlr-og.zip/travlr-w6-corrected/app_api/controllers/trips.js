const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

/* GET all trips */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({});

    res.status(200).json(trips);
  } catch (err) {
    console.error('Error retrieving trips:', err);

    res.status(500).json({
      message: 'Unable to retrieve trips',
      error: err.message
    });
  }
};

/* GET one trip by trip code */
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.params.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    res.status(200).json(trip);
  } catch (err) {
    console.error('Error retrieving trip:', err);

    res.status(500).json({
      message: 'Unable to retrieve trip',
      error: err.message
    });
  }
};

/* POST a new trip */
const tripsAddTrip = async (req, res) => {
  try {
    const {
      code,
      name,
      length,
      start,
      resort,
      perPerson,
      image,
      description
    } = req.body;

    if (
      !code ||
      !name ||
      !length ||
      !start ||
      !resort ||
      !perPerson ||
      !image ||
      !description
    ) {
      return res.status(400).json({
        message: 'All trip fields are required'
      });
    }

    const existingTrip = await Trip.findOne({ code });

    if (existingTrip) {
      return res.status(409).json({
        message: 'A trip with this code already exists'
      });
    }

    const newTrip = await Trip.create({
      code,
      name,
      length,
      start,
      resort,
      perPerson,
      image,
      description
    });

    res.status(201).json(newTrip);
  } catch (err) {
    console.error('Error adding trip:', err);

    res.status(500).json({
      message: 'Unable to add trip',
      error: err.message
    });
  }
};

/* PUT updates an existing trip */
const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip.findOneAndUpdate(
      {
        code: req.params.tripCode
      },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
      },
      {
        new: true,
        runValidators: true
      }
    );

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    res.status(200).json(trip);
  } catch (err) {
    console.error('Error updating trip:', err);

    res.status(500).json({
      message: 'Unable to update trip',
      error: err.message
    });
  }
};

/* DELETE an existing trip */
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Trip.findOneAndDelete({
      code: req.params.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found'
      });
    }

    res.status(204).send();
  } catch (err) {
    console.error('Error deleting trip:', err);

    res.status(500).json({
      message: 'Unable to delete trip',
      error: err.message
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};