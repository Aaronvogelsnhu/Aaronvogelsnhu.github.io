package com.example.aaronvogel_androidlayouteditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class InventoryDataManagerTest {

    @Test
    public void findByIdReturnsTheItemStoredInTheHashMap() {
        InventoryDataManager manager = new InventoryDataManager();
        InventoryItem pineBoard = new InventoryItem(12, "Pine Board", "Lumber", 25, 10);

        manager.upsert(pineBoard);

        assertEquals(pineBoard, manager.findById(12));
    }

    @Test
    public void lowStockQueueReturnsTheLargestShortageFirst() {
        InventoryDataManager manager = new InventoryDataManager();
        InventoryItem decking = new InventoryItem(1, "Decking", "Lumber", 4, 10);
        InventoryItem screws = new InventoryItem(2, "Screws", "Hardware", 1, 5);
        InventoryItem plywood = new InventoryItem(3, "Plywood", "Sheet Goods", 12, 10);

        manager.upsert(decking);
        manager.upsert(screws);
        manager.upsert(plywood);

        assertEquals(decking, manager.getHighestPriorityLowStockItem());
        assertEquals(2, manager.getLowStockItemCount());
    }

    @Test
    public void updateRemovesAnItemFromTheLowStockQueueWhenStockIsHealthy() {
        InventoryDataManager manager = new InventoryDataManager();

        manager.upsert(new InventoryItem(7, "Two by Four", "Lumber", 3, 10));
        manager.upsert(new InventoryItem(7, "Two by Four", "Lumber", 15, 10));

        assertEquals(1, manager.getInventoryCount());
        assertEquals(0, manager.getLowStockItemCount());
        assertNull(manager.getHighestPriorityLowStockItem());
    }

    @Test
    public void removeKeepsAllDataStructuresInSync() {
        InventoryDataManager manager = new InventoryDataManager();
        manager.upsert(new InventoryItem(9, "Joist Hanger", "Hardware", 2, 8));

        assertTrue(manager.remove(9));

        assertFalse(manager.remove(9));
        assertNull(manager.findById(9));
        assertEquals(0, manager.getInventoryCount());
        assertEquals(0, manager.getLowStockItemCount());
    }
}
