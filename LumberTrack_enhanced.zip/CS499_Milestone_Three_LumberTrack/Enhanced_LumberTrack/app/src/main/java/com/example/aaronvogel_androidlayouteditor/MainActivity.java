package com.example.aaronvogel_androidlayouteditor;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private static final int CELL_PADDING = 10;
    private static final String PREFS_NAME = "lumbertrack_prefs";
    private static final String PREF_PHONE_NUMBER = "phone_number";

    private DatabaseHelper databaseHelper;
    private EditText editItemName;
    private EditText editCategory;
    private EditText editQuantity;
    private EditText editLowStock;
    private EditText editPhoneNumber;
    private TextView textPermissionStatus;
    private TextView textSelectedItem;
    private TextView textLowStockPriority;
    private TableLayout tableInventory;
    private int selectedItemId = -1;
    private final InventoryDataManager inventoryDataManager = new InventoryDataManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseHelper = new DatabaseHelper(this);
        showLoginScreen();
    }

    private void showLoginScreen() {
        editPhoneNumber = null;
        textPermissionStatus = null;
        setContentView(R.layout.activity_main);

        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(view -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, R.string.login_empty_error, Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.checkLogin(username, password)) {
                Toast.makeText(this, R.string.login_success, Toast.LENGTH_SHORT).show();
                showInventoryScreen();
            } else {
                Toast.makeText(this, R.string.login_failed, Toast.LENGTH_SHORT).show();
            }
        });

        buttonCreateAccount.setOnClickListener(view -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, R.string.login_empty_error, Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.userExists(username)) {
                Toast.makeText(this, R.string.user_exists, Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.createUser(username, password)) {
                Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();
                showInventoryScreen();
            } else {
                Toast.makeText(this, R.string.account_error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showInventoryScreen() {
        editPhoneNumber = null;
        textPermissionStatus = null;
        setContentView(R.layout.activity_inventory);

        editItemName = findViewById(R.id.editItemName);
        editCategory = findViewById(R.id.editCategory);
        editQuantity = findViewById(R.id.editQuantity);
        editLowStock = findViewById(R.id.editLowStock);
        textSelectedItem = findViewById(R.id.textSelectedItem);
        textLowStockPriority = findViewById(R.id.textLowStockPriority);
        tableInventory = findViewById(R.id.tableInventory);

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        Button buttonUpdateItem = findViewById(R.id.buttonUpdateItem);
        Button buttonClearFields = findViewById(R.id.buttonClearFields);
        Button buttonOpenSms = findViewById(R.id.buttonOpenSms);

        loadInventoryGrid();

        buttonAddItem.setOnClickListener(view -> addItem());
        buttonUpdateItem.setOnClickListener(view -> updateSelectedItem());
        buttonClearFields.setOnClickListener(view -> clearInventoryFields());
        buttonOpenSms.setOnClickListener(view -> showSmsScreen());
    }

    private void addItem() {
        InventoryForm form = readInventoryForm();

        if (form == null) {
            return;
        }

        long result = databaseHelper.addInventoryItem(
                form.itemName,
                form.category,
                form.quantity,
                form.lowStock
        );

        if (result != -1) {
            InventoryItem newItem = new InventoryItem(
                    (int) result,
                    form.itemName,
                    form.category,
                    form.quantity,
                    form.lowStock
            );
            inventoryDataManager.upsert(newItem);
            Toast.makeText(this, R.string.item_added, Toast.LENGTH_SHORT).show();
            sendLowStockAlertIfNeeded(form.itemName, form.quantity, form.lowStock);
            clearInventoryFields();
            renderInventoryGrid();
        } else {
            Toast.makeText(this, R.string.item_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void updateSelectedItem() {
        if (selectedItemId == -1) {
            Toast.makeText(this, R.string.select_item_first, Toast.LENGTH_SHORT).show();
            return;
        }

        InventoryForm form = readInventoryForm();

        if (form == null) {
            return;
        }

        int itemId = selectedItemId;
        boolean updated = databaseHelper.updateInventoryItem(
                itemId,
                form.itemName,
                form.category,
                form.quantity,
                form.lowStock
        );

        if (updated) {
            inventoryDataManager.upsert(new InventoryItem(
                    itemId,
                    form.itemName,
                    form.category,
                    form.quantity,
                    form.lowStock
            ));
            Toast.makeText(this, R.string.item_updated, Toast.LENGTH_SHORT).show();
            sendLowStockAlertIfNeeded(form.itemName, form.quantity, form.lowStock);
            clearInventoryFields();
            renderInventoryGrid();
        } else {
            Toast.makeText(this, R.string.item_error, Toast.LENGTH_SHORT).show();
        }
    }

    private InventoryForm readInventoryForm() {
        String itemName = editItemName.getText().toString().trim();
        String category = editCategory.getText().toString().trim();
        String quantityText = editQuantity.getText().toString().trim();
        String lowStockText = editLowStock.getText().toString().trim();

        if (itemName.isEmpty() || category.isEmpty() || quantityText.isEmpty() || lowStockText.isEmpty()) {
            Toast.makeText(this, R.string.inventory_empty_error, Toast.LENGTH_SHORT).show();
            return null;
        }

        try {
            int quantity = Integer.parseInt(quantityText);
            int lowStock = Integer.parseInt(lowStockText);
            return new InventoryForm(itemName, category, quantity, lowStock);
        } catch (NumberFormatException error) {
            Toast.makeText(this, R.string.number_error, Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void loadInventoryGrid() {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = databaseHelper.getAllInventoryItems();

        try {
            while (cursor.moveToNext()) {
                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.ITEM_NAME));
                String category = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.CATEGORY));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.QUANTITY));
                int lowStock = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.LOW_STOCK));

                items.add(new InventoryItem(itemId, itemName, category, quantity, lowStock));
            }
        } finally {
            cursor.close();
        }

        inventoryDataManager.replaceAll(items);
        renderInventoryGrid();
    }

    private void renderInventoryGrid() {
        tableInventory.removeAllViews();
        addHeaderRow();

        List<InventoryItem> items = inventoryDataManager.getInventoryList();
        if (items.isEmpty()) {
            addEmptyRow();
            updateLowStockPriorityText();
            return;
        }

        for (InventoryItem item : items) {
            addInventoryRow(item);
        }

        updateLowStockPriorityText();
    }

    private void addHeaderRow() {
        TableRow row = new TableRow(this);
        row.setBackgroundColor(0xFF4B6F44);
        row.addView(makeHeaderCell(getString(R.string.item)));
        row.addView(makeHeaderCell(getString(R.string.category)));
        row.addView(makeHeaderCell(getString(R.string.qty)));
        row.addView(makeHeaderCell(getString(R.string.low)));
        row.addView(makeHeaderCell(getString(R.string.edit)));
        row.addView(makeHeaderCell(getString(R.string.delete)));
        tableInventory.addView(row);
    }

    private void addInventoryRow(InventoryItem item) {
        TableRow row = new TableRow(this);
        row.addView(makeBodyCell(item.getItemName()));
        row.addView(makeBodyCell(item.getCategory()));
        row.addView(makeBodyCell(String.valueOf(item.getQuantity())));
        row.addView(makeBodyCell(String.valueOf(item.getLowStock())));

        Button buttonEdit = new Button(this);
        buttonEdit.setText(R.string.edit);
        buttonEdit.setOnClickListener(view -> selectItemForEditing(item.getId()));
        row.addView(buttonEdit);

        Button buttonDelete = new Button(this);
        buttonDelete.setText(R.string.delete);
        buttonDelete.setOnClickListener(view -> deleteItem(item.getId()));
        row.addView(buttonDelete);

        tableInventory.addView(row);
    }

    private void addEmptyRow() {
        TableRow row = new TableRow(this);
        TextView emptyCell = makeBodyCell(getString(R.string.no_items));
        emptyCell.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT, 6));
        row.addView(emptyCell);
        tableInventory.addView(row);
    }

    private void selectItemForEditing(int itemId) {
        InventoryItem item = inventoryDataManager.findById(itemId);
        if (item == null) {
            Toast.makeText(this, R.string.item_error, Toast.LENGTH_SHORT).show();
            return;
        }

        selectedItemId = item.getId();
        editItemName.setText(item.getItemName());
        editCategory.setText(item.getCategory());
        editQuantity.setText(String.valueOf(item.getQuantity()));
        editLowStock.setText(String.valueOf(item.getLowStock()));
        textSelectedItem.setText(getString(R.string.selected_item, item.getItemName()));
    }

    private void deleteItem(int itemId) {
        boolean deleted = databaseHelper.deleteInventoryItem(itemId);

        if (deleted) {
            inventoryDataManager.remove(itemId);
            Toast.makeText(this, R.string.item_deleted, Toast.LENGTH_SHORT).show();
            clearInventoryFields();
            renderInventoryGrid();
        } else {
            Toast.makeText(this, R.string.item_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void clearInventoryFields() {
        selectedItemId = -1;
        editItemName.setText("");
        editCategory.setText("");
        editQuantity.setText("");
        editLowStock.setText("");
        textSelectedItem.setText(R.string.no_item_selected);
    }

    private TextView makeHeaderCell(String text) {
        TextView textView = makeBodyCell(text);
        textView.setTextColor(0xFFFFFFFF);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        return textView;
    }

    private TextView makeBodyCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(CELL_PADDING, CELL_PADDING, CELL_PADDING, CELL_PADDING);
        return textView;
    }

    private void updateLowStockPriorityText() {
        InventoryItem priorityItem = inventoryDataManager.getHighestPriorityLowStockItem();

        if (priorityItem == null) {
            textLowStockPriority.setText(R.string.low_stock_priority_empty);
            return;
        }

        textLowStockPriority.setText(getString(
                R.string.low_stock_priority_item,
                priorityItem.getItemName(),
                priorityItem.getQuantity(),
                priorityItem.getLowStock()
        ));
    }

    private void showSmsScreen() {
        setContentView(R.layout.activity_sms);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        editPhoneNumber.setText(getSavedPhoneNumber());

        Button buttonRequestSmsPermission = findViewById(R.id.buttonRequestSmsPermission);
        Button buttonSendTestAlert = findViewById(R.id.buttonSendTestAlert);
        Button buttonBackToInventory = findViewById(R.id.buttonBackToInventory);

        updateSmsStatus();

        buttonRequestSmsPermission.setOnClickListener(view -> requestSmsPermission());
        buttonSendTestAlert.setOnClickListener(view -> sendTestLowStockAlert());
        buttonBackToInventory.setOnClickListener(view -> {
            savePhoneNumberFromInput();
            showInventoryScreen();
        });
    }

    private boolean hasSmsPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }

        return checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        savePhoneNumberFromInput();

        if (hasSmsPermission()) {
            updateSmsStatus();
            Toast.makeText(this, R.string.sms_already_granted, Toast.LENGTH_SHORT).show();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void updateSmsStatus() {
        if (textPermissionStatus == null) {
            return;
        }

        if (hasSmsPermission()) {
            textPermissionStatus.setText(R.string.sms_granted);
        } else {
            textPermissionStatus.setText(R.string.sms_denied_message);
        }
    }

    private void sendTestLowStockAlert() {
        sendSmsMessage(getString(R.string.test_sms_message));
    }

    private void sendLowStockAlertIfNeeded(String itemName, int quantity, int lowStock) {
        if (quantity <= lowStock) {
            String message = getString(R.string.low_stock_sms_message, itemName, quantity);
            sendSmsMessage(message);
        }
    }

    private void sendSmsMessage(String message) {
        if (!hasSmsPermission()) {
            Toast.makeText(this, R.string.sms_denied_toast, Toast.LENGTH_SHORT).show();
            return;
        }

        String phoneNumber = getPhoneNumberForSms();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, R.string.phone_empty_error, Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, R.string.sms_sent, Toast.LENGTH_SHORT).show();
        } catch (Exception error) {
            Toast.makeText(this, R.string.sms_failed, Toast.LENGTH_LONG).show();
        }
    }

    private String getPhoneNumberForSms() {
        if (editPhoneNumber != null) {
            savePhoneNumberFromInput();
            return editPhoneNumber.getText().toString().trim();
        }

        return getSavedPhoneNumber();
    }

    private void savePhoneNumberFromInput() {
        if (editPhoneNumber == null) {
            return;
        }

        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit()
                .putString(PREF_PHONE_NUMBER, editPhoneNumber.getText().toString().trim())
                .apply();
    }

    private String getSavedPhoneNumber() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return preferences.getString(PREF_PHONE_NUMBER, "");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            updateSmsStatus();

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.sms_enabled, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, R.string.sms_denied_toast, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /** Small helper class for clean inventory form handling. */
    private static class InventoryForm {
        String itemName;
        String category;
        int quantity;
        int lowStock;

        InventoryForm(String itemName, String category, int quantity, int lowStock) {
            this.itemName = itemName;
            this.category = category;
            this.quantity = quantity;
            this.lowStock = lowStock;
        }
    }
}
