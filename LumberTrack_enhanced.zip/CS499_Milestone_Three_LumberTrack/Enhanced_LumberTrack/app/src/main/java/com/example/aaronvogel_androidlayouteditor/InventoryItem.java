package com.example.aaronvogel_androidlayouteditor;

/**
 * Immutable inventory record used by the list, map, and priority queue.
 */
public final class InventoryItem {

    private final int id;
    private final String itemName;
    private final String category;
    private final int quantity;
    private final int lowStock;

    public InventoryItem(int id, String itemName, String category, int quantity, int lowStock) {
        this.id = id;
        this.itemName = itemName;
        this.category = category;
        this.quantity = quantity;
        this.lowStock = lowStock;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCategory() {
        return category;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getLowStock() {
        return lowStock;
    }

    public boolean isLowStock() {
        return quantity <= lowStock;
    }

    /**
     * Returns how far the quantity is below the configured low-stock level.
     * A larger value means the item should receive higher low-stock priority.
     */
    public int getStockUrgency() {
        return Math.max(lowStock - quantity, 0);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }

        if (!(other instanceof InventoryItem)) {
            return false;
        }

        InventoryItem item = (InventoryItem) other;
        return id == item.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
