package com.example.aaronvogel_androidlayouteditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;

/**
 * Maintains synchronized inventory data structures for display, lookup, and low-stock priority.
 */
public final class InventoryDataManager {

    private static final Comparator<InventoryItem> DISPLAY_ORDER =
            Comparator.comparing(InventoryItem::getItemName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparingInt(InventoryItem::getId);

    private static final Comparator<InventoryItem> LOW_STOCK_PRIORITY =
            Comparator.comparingInt(InventoryItem::getStockUrgency)
                    .reversed()
                    .thenComparing(InventoryItem::getItemName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparingInt(InventoryItem::getId);

    // List keeps the alphabetical order needed to render the inventory table.
    private final List<InventoryItem> inventoryList = new ArrayList<>();

    // Map provides average O(1) lookup by SQLite item ID instead of a linear list search.
    private final Map<Integer, InventoryItem> inventoryById = new HashMap<>();

    // Queue keeps the item with the largest shortage at the head for O(1) priority access.
    private final PriorityQueue<InventoryItem> lowStockQueue =
            new PriorityQueue<>(LOW_STOCK_PRIORITY);

    /**
     * Rebuilds the indexes after a database load. The final display sort is O(n log n).
     */
    public void replaceAll(List<InventoryItem> items) {
        clear();
        for (InventoryItem item : items) {
            InventoryItem previousItem = inventoryById.put(item.getId(), item);
            if (previousItem != null) {
                inventoryList.remove(previousItem);
                lowStockQueue.remove(previousItem);
            }

            inventoryList.add(item);
            if (item.isLowStock()) {
                lowStockQueue.offer(item);
            }
        }

        inventoryList.sort(DISPLAY_ORDER);
    }

    public void upsert(InventoryItem item) {
        Objects.requireNonNull(item, "item cannot be null");

        InventoryItem previousItem = inventoryById.put(item.getId(), item);
        if (previousItem != null) {
            inventoryList.remove(previousItem);
            lowStockQueue.remove(previousItem);
        }

        inventoryList.add(item);
        inventoryList.sort(DISPLAY_ORDER);

        if (item.isLowStock()) {
            lowStockQueue.offer(item);
        }
    }

    public boolean remove(int itemId) {
        InventoryItem removedItem = inventoryById.remove(itemId);
        if (removedItem == null) {
            return false;
        }

        inventoryList.remove(removedItem);
        lowStockQueue.remove(removedItem);
        return true;
    }

    /**
     * Uses the HashMap for average O(1) lookup by item ID.
     */
    public InventoryItem findById(int itemId) {
        return inventoryById.get(itemId);
    }

    public List<InventoryItem> getInventoryList() {
        return Collections.unmodifiableList(new ArrayList<>(inventoryList));
    }

    /**
     * Returns the most urgent low-stock item in O(1) time, or null when stock is healthy.
     */
    public InventoryItem getHighestPriorityLowStockItem() {
        return lowStockQueue.peek();
    }

    public int getLowStockItemCount() {
        return lowStockQueue.size();
    }

    public int getInventoryCount() {
        return inventoryList.size();
    }

    private void clear() {
        inventoryList.clear();
        inventoryById.clear();
        lowStockQueue.clear();
    }
}
