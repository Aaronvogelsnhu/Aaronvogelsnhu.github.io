# Algorithm and Data Structure Analysis

## Original Approach

Before the enhancement, the app pulled inventory records from SQLite one at a time when it displayed them. This worked with only a few items, but it was not a fast way to find an item by ID or see which low-stock item needed attention first.

## Enhanced Approach

To make the app easier to work with, I created the `InventoryDataManager` class. When data loads from SQLite, this class puts the items into these three structures:

| Structure | Purpose | Main benefit |
| --- | --- | --- |
| `ArrayList<InventoryItem>` | Shows inventory in alphabetical order | Simple ordered traversal for the table |
| `HashMap<Integer, InventoryItem>` | Finds an item from its SQLite ID | Average O(1) lookup instead of scanning a display list |
| `PriorityQueue<InventoryItem>` | Tracks low-stock items by shortage | O(1) access to the most urgent low-stock item |

An item goes into the low-stock queue once its quantity reaches its alert level or falls below it. Items furthest below their alert amount move to the top. The app uses `peek()` to show the next item that needs restocking without rearranging the other records.

## Complexity and Tradeoffs

| Operation | Enhanced complexity | Reason |
| --- | --- | --- |
| Load and sort inventory | O(n log n) | The list is sorted once after data is loaded from SQLite |
| Find item by ID | Average O(1) | HashMap lookup by unique SQLite item ID |
| Get highest low-stock priority | O(1) | PriorityQueue `peek()` returns the front item |
| Add a low-stock item | O(log n) | PriorityQueue insertion maintains priority order |
| Update or delete an item | O(n) to O(n log n) | The previous item is removed from the list and queue, then the display list is sorted |

Keeping the list, map, and queue in memory takes O(n) extra space. I thought that was worth it because the app can find and update an item more easily, and it can show the next low-stock item right away. SQLite still keeps the saved copy of the inventory.
