## LumberTrack Algorithms and Data Structures Enhancement

This submission contains the original LumberTrack Android inventory application and the enhanced version prepared for CS 499 Milestone Three.

## Contents

- `Original_LumberTrack` contains the original source files from CS 360.
- `Enhanced_LumberTrack` contains the improved source files, unit tests, layouts, and resources.
- `ALGORITHM_ANALYSIS.md` explains the data-structure decisions and time-complexity tradeoffs.

## Enhancement Summary

The enhanced app keeps the SQLite database as the persistent source of inventory data. When the inventory screen loads, the app reads the database into an `InventoryDataManager`. The manager keeps three synchronized data structures:

- An `ArrayList` for the alphabetically ordered inventory table.
- A `HashMap` keyed by each SQLite item ID for fast item lookup during editing.
- A `PriorityQueue` for low-stock items, with the largest shortage at the front of the queue.

I update the ArrayList, HashMap, and priority queue whenever an inventory item changes so they stay in sync. The screen then shows the low-stock item that needs attention first.

## Verification Files

`Enhanced_LumberTrack/app/src/test/java/com/example/aaronvogel_androidlayouteditor/InventoryDataManagerTest.java` includes tests for map lookup, low-stock priority order, updating inventory, and deletion synchronization.

## Opening the Project

Start by opening the project folder in Android Studio. Once it finishes syncing, run the app on an emulator or your phone. If you are using the enhanced version, also run the tests in the `InventoryDataManagerTest` class.
