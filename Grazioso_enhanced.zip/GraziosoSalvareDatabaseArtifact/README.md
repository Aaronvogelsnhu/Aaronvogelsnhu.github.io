Grazioso Salvare Database Artifact

The CS 340 animal rescue dashboard utilises the MongoDB collection aac.animals. The enhanced version of the project retains the original dashboard and CRUD module in the original/ directory and has the updated files in the root of the project. The hard-coded example password from the original notebook has been redacted in this version.

What changed

* Added MongoDB JSON schema validation for new records as well as for updates to existing valid records.
* Added a compound index on the fields used by the rescue type filters.
* Added server side pagination, approved sort fields and escaped the literal breed search.
* Added the breed count aggregation so the dashboard chart will be summarising the matching records in MongoDB.
* Changed the update and delete to operate on one record at a time and will reject empty or operator based filters.
* Credentials have been removed from the notebook. The database URI now comes from MONGODB_URI.
* Added unit tests and a benchmark script which benchmarks a forced collection scan against the compound index using the same query.

Setup

1. Install the packages as per requirements.txt.
2. Copy .env.example to .env and replace the placeholder password, or set MONGODB_URI in the shell prior to starting Python.
3. Run python setup_database.py once. The account will need permission to change collection validation and to create indexes. If the database user doesn't have that permission then an authorised DBA will need to run this setup step.
4. Open ProjectTwoDashboard.ipynb in Jupyter and run the cell.

The notebook uses aac.animals, consistent with the original project. This ZIP does not contain a database dump or any animal records.

Checks

MongoDB is not needed:

python -m unittest discover -s tests -v

Start MongoDB and load the AAC records first:

python benchmark_queries.py --repetitions 5 --limit 100 --output benchmark_results.json

The benchmark prints out the returned count, the number of docs and keys examined, the server execution time, the median client elapsed time and the query plan stages for each run. It forces the collection scan for the baseline and the compound index for the indexed run. The results will of course vary depending on the local server and dataset. The project ZIP doesn't contain any of the measured timings.

Security and data handling

The dashboard needs a database login with access only to the data it uses. Keep its password out of the source code in a local .env file that is not shared. If MongoDB returns an error, show the user a message like “Unable to load dashboard data” instead of displaying the technical details.