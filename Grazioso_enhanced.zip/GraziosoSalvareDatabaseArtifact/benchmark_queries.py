"""Compare a forced collection scan with the rescue-filter compound index.

Run this only against a MongoDB collection that contains the AAC animal records.
The two plans are forced with hints so the query shape remains the same.
"""
import argparse
import json
import statistics
import time
from pathlib import Path

from CRUD_Python_Module import AnimalShelter, DatabaseOperationError, PyMongoError


SORT_FIELD = "age_upon_outcome_in_weeks"


def _stage_names(value, collected=None):
    if collected is None:
        collected = []
    if isinstance(value, dict):
        if isinstance(value.get("stage"), str):
            collected.append(value["stage"])
        for child in value.values():
            _stage_names(child, collected)
    elif isinstance(value, list):
        for child in value:
            _stage_names(child, collected)
    return sorted(set(collected))


def _find_command(shelter, query, hint, limit):
    return {
        "find": shelter.COLLECTION_NAME,
        "filter": query,
        "projection": {"_id": 0, "animal_id": 1},
        "sort": {SORT_FIELD: 1},
        "limit": limit,
        "hint": hint,
    }


def measure(shelter, query, hint, limit, repetitions):
    command = _find_command(shelter, query, hint, limit)
    explanation = shelter.database.command(
        "explain",
        command,
        verbosity="executionStats",
    )
    stats = explanation.get("executionStats", {})
    durations = []

    for _ in range(repetitions):
        started = time.perf_counter()
        cursor = (
            shelter.collection.find(
                query,
                {"_id": 0, "animal_id": 1},
            )
            .sort([(SORT_FIELD, 1)])
            .hint(hint)
            .limit(limit)
        )
        list(cursor)
        durations.append((time.perf_counter() - started) * 1000)

    return {
        "hint": hint,
        "n_returned": stats.get("nReturned"),
        "documents_examined": stats.get("totalDocsExamined"),
        "keys_examined": stats.get("totalKeysExamined"),
        "server_execution_ms": stats.get("executionTimeMillis"),
        "median_client_elapsed_ms": round(statistics.median(durations), 3),
        "plan_stages": _stage_names(explanation.get("queryPlanner", {}).get("winningPlan", {})),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--filter", choices=("water", "mountain", "disaster"), default="water")
    parser.add_argument("--output", type=Path, help="Optional path for the JSON results.")
    args = parser.parse_args()

    if args.repetitions < 1:
        parser.error("--repetitions must be at least 1")
    if args.limit < 1 or args.limit > AnimalShelter.MAX_PAGE_SIZE:
        parser.error(f"--limit must be from 1 to {AnimalShelter.MAX_PAGE_SIZE}")

    shelter = None
    try:
        shelter = AnimalShelter()
        query = AnimalShelter.build_filter(args.filter)
        collection_scan = measure(
            shelter, query, "$natural", args.limit, args.repetitions
        )
        shelter.create_indexes()
        indexed = measure(
            shelter,
            query,
            AnimalShelter.RESCUE_INDEX_NAME,
            args.limit,
            args.repetitions,
        )
        results = {
            "filter": args.filter,
            "repetitions": args.repetitions,
            "limit": args.limit,
            "comparison_note": (
                "The baseline forces a collection scan; the second run forces "
                "the compound rescue-filter index. Timings depend on the local "
                "MongoDB server, dataset, cache, and machine."
            ),
            "collection_scan": collection_scan,
            "compound_index": indexed,
        }
        serialized = json.dumps(results, indent=2)
        print(serialized)
        if args.output:
            args.output.write_text(serialized + "\n", encoding="utf-8")
            print(f"Results saved to {args.output}")
    except (RuntimeError, DatabaseOperationError, PyMongoError):
        print("Benchmark failed. Check the MongoDB connection, permissions, and index setup.")
        raise SystemExit(1)
    finally:
        if shelter is not None:
            shelter.close()


if __name__ == "__main__":
    main()

