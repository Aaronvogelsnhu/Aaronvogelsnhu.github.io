"""Apply database validation and indexes once before launching the dashboard."""
from CRUD_Python_Module import AnimalShelter, DatabaseOperationError


def main():
    shelter = None
    try:
        shelter = AnimalShelter()
        indexes = shelter.ensure_schema_and_indexes()
        print("Schema validation is configured.")
        print("Indexes ready: " + ", ".join(indexes))
    except (RuntimeError, DatabaseOperationError) as exc:
        print(str(exc))
        raise SystemExit(1)
    finally:
        if shelter is not None:
            shelter.close()


if __name__ == "__main__":
    main()

