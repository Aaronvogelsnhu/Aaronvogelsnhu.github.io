"""Database access for the Grazioso Salvare animal rescue dashboard.

Database credentials are read from MONGODB_URI. The dashboard does not store
credentials in its notebook or source code.
"""
from copy import deepcopy
import os
import re

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    from pymongo import ASCENDING, DESCENDING, MongoClient
    from pymongo.errors import PyMongoError
except ImportError:
    MongoClient = None
    ASCENDING = 1
    DESCENDING = -1

    class PyMongoError(Exception):
        """Fallback used so validation helpers and unit tests work without PyMongo."""


class DatabaseOperationError(RuntimeError):
    """Safe, user-facing database error that does not expose connection details."""


class AnimalShelter:
    """CRUD and reporting operations for the aac.animals collection."""

    DB_NAME = "aac"
    COLLECTION_NAME = "animals"
    DEFAULT_PAGE_SIZE = 10
    MAX_PAGE_SIZE = 100
    MAX_PAGE_NUMBER = 10000

    ALLOWED_FIELDS = frozenset({
        "animal_id",
        "animal_type",
        "age_upon_outcome",
        "breed",
        "color",
        "date_of_birth",
        "outcome_subtype",
        "outcome_type",
        "sex_upon_outcome",
        "location_lat",
        "location_long",
        "age_upon_outcome_in_weeks",
        "name",
        "Unnamed: 0",
    })

    SORT_FIELDS = frozenset({
        "animal_id",
        "animal_type",
        "breed",
        "age_upon_outcome_in_weeks",
        "outcome_type",
        "date_of_birth",
    })

    RESCUE_INDEX_NAME = "idx_rescue_filter"
    RESCUE_INDEX_KEYS = [
        ("animal_type", ASCENDING),
        ("sex_upon_outcome", ASCENDING),
        ("age_upon_outcome_in_weeks", ASCENDING),
    ]

    SCHEMA_VALIDATOR = {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["animal_id", "animal_type", "breed"],
            "properties": {
                "animal_id": {"bsonType": "string"},
                "animal_type": {"bsonType": "string"},
                "breed": {"bsonType": "string"},
                "age_upon_outcome": {"bsonType": ["string", "null"]},
                "color": {"bsonType": ["string", "null"]},
                "date_of_birth": {"bsonType": ["string", "null"]},
                "outcome_subtype": {"bsonType": ["string", "null"]},
                "outcome_type": {"bsonType": ["string", "null"]},
                "sex_upon_outcome": {"bsonType": ["string", "null"]},
                "name": {"bsonType": ["string", "null"]},
                "age_upon_outcome_in_weeks": {
                    "bsonType": ["double", "int", "long", "decimal", "null"]
                },
                "location_lat": {
                    "bsonType": ["double", "int", "long", "decimal", "null"]
                },
                "location_long": {
                    "bsonType": ["double", "int", "long", "decimal", "null"]
                },
            },
        }
    }

    _RESCUE_BREEDS = {
        "water": (
            "Labrador Retriever",
            "Chesapeake Bay Retriever",
            "Newfoundland",
        ),
        "mountain": (
            "German Shepherd",
            "Alaskan Malamute",
            "Old English Sheepdog",
            "Siberian Husky",
            "Rottweiler",
        ),
        "disaster": (
            "Doberman Pinscher",
            "German Shepherd",
            "Golden Retriever",
            "Bloodhound",
            "Rottweiler",
        ),
    }

    _RESCUE_DETAILS = {
        "water": {
            "animal_type": "Dog",
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        },
        "mountain": {
            "animal_type": "Dog",
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
        },
        "disaster": {
            "animal_type": "Dog",
            "sex_upon_outcome": "Intact Male",
            "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
        },
    }

    def __init__(self, uri=None, client=None):
        """Connect using an explicit URI or the MONGODB_URI environment variable."""
        if client is None:
            uri = uri or os.getenv("MONGODB_URI")
            if not uri:
                raise RuntimeError(
                    "Set MONGODB_URI before connecting to the animal shelter database."
                )
            if MongoClient is None:
                raise RuntimeError(
                    "PyMongo is required. Install the dependencies in requirements.txt."
                )
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        else:
            self.client = client

        self.database = self.client[self.DB_NAME]
        self.collection = self.database[self.COLLECTION_NAME]

    @staticmethod
    def _is_scalar(value):
        return value is None or isinstance(value, (str, int, float, bool))

    @classmethod
    def _validate_equality_query(cls, query, allow_empty=False):
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")
        if not query and not allow_empty:
            raise ValueError("A non-empty filter is required for this operation.")

        for field, value in query.items():
            if field not in cls.ALLOWED_FIELDS:
                raise ValueError("Query contains an unsupported field.")
            if not cls._is_scalar(value):
                raise ValueError("Only simple field equality filters are accepted.")
        return query

    @classmethod
    def _validate_page_size(cls, page_size):
        if isinstance(page_size, bool) or not isinstance(page_size, int):
            raise ValueError("Page size must be a whole number.")
        if page_size < 1 or page_size > cls.MAX_PAGE_SIZE:
            raise ValueError(f"Page size must be between 1 and {cls.MAX_PAGE_SIZE}.")
        return page_size

    @classmethod
    def _validate_page_number(cls, page):
        if isinstance(page, bool) or not isinstance(page, int):
            raise ValueError("Page must be a whole number.")
        if page < 0 or page > cls.MAX_PAGE_NUMBER:
            raise ValueError("Page is outside the supported range.")
        return page

    @classmethod
    def _validate_update_values(cls, new_values):
        if not isinstance(new_values, dict) or not new_values:
            raise ValueError("Update values must be a non-empty dictionary.")
        for field, value in new_values.items():
            if field not in cls.ALLOWED_FIELDS or field == "_id":
                raise ValueError("Update contains an unsupported field.")
            if not cls._is_scalar(value):
                raise ValueError("Only simple values can be updated.")
        return new_values

    @classmethod
    def build_filter(cls, filter_type="reset", breed_search=None):
        """Build a MongoDB filter from approved dashboard choices.

        User text is escaped and treated as a literal breed search. MongoDB
        operators and field names are never accepted from the browser.
        """
        selected = (filter_type or "reset").strip().lower()
        if selected in ("reset", "all"):
            query = {}
        elif selected in cls._RESCUE_DETAILS:
            query = deepcopy(cls._RESCUE_DETAILS[selected])
            query["$or"] = [
                {"breed": {"$regex": re.escape(breed), "$options": "i"}}
                for breed in cls._RESCUE_BREEDS[selected]
            ]
        else:
            raise ValueError("Select a supported rescue type or reset the filter.")

        if breed_search is not None:
            if not isinstance(breed_search, str):
                raise ValueError("Breed search must be text.")
            breed_search = breed_search.strip()
            if len(breed_search) > 80:
                raise ValueError("Breed search must be 80 characters or fewer.")
            if breed_search:
                query["breed"] = {
                    "$regex": re.escape(breed_search),
                    "$options": "i",
                }
        return query

    def create(self, data):
        """Insert one animal record. MongoDB validation checks the document schema."""
        if not isinstance(data, dict) or not data:
            raise ValueError("Animal data must be a non-empty dictionary.")
        if not {"animal_id", "animal_type", "breed"}.issubset(data):
            raise ValueError("Animal data needs animal_id, animal_type, and breed.")
        if "_id" in data or any(field not in self.ALLOWED_FIELDS for field in data):
            raise ValueError("Animal data contains an unsupported field.")
        if any(not self._is_scalar(value) for value in data.values()):
            raise ValueError("Animal data values must be simple fields.")

        try:
            result = self.collection.insert_one(deepcopy(data))
            return bool(result.acknowledged)
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database create failed. Check the connection and document values."
            ) from exc

    def read(self, query=None, limit=100, skip=0):
        """Read a bounded page using simple equality filters only."""
        query = {} if query is None else query
        self._validate_equality_query(query, allow_empty=True)
        limit = self._validate_page_size(limit)
        skip = self._validate_page_number(skip)

        try:
            cursor = self.collection.find(query, {"_id": 0})
            return list(cursor.skip(skip).limit(limit))
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database read failed. Check the connection and query."
            ) from exc

    def update(self, query, new_values):
        """Update at most one record; empty or operator-based filters are rejected."""
        self._validate_equality_query(query)
        self._validate_update_values(new_values)

        try:
            result = self.collection.update_one(query, {"$set": deepcopy(new_values)})
            return result.modified_count
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database update failed. Check the connection and values."
            ) from exc

    def delete(self, query):
        """Delete at most one record; an empty filter can never delete the collection."""
        self._validate_equality_query(query)

        try:
            result = self.collection.delete_one(query)
            return result.deleted_count
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database delete failed. Check the connection and filter."
            ) from exc

    def search_page(
        self,
        filter_type="reset",
        breed_search=None,
        page=0,
        page_size=DEFAULT_PAGE_SIZE,
        sort_by="animal_id",
        descending=False,
    ):
        """Return one server-side page and the matching result count."""
        query = self.build_filter(filter_type, breed_search)
        page = self._validate_page_number(page)
        page_size = self._validate_page_size(page_size)
        if sort_by not in self.SORT_FIELDS:
            raise ValueError("Select a supported sort field.")
        if not isinstance(descending, bool):
            raise ValueError("Sort direction must be ascending or descending.")

        skip = page * page_size
        direction = DESCENDING if descending else ASCENDING
        try:
            total = self.collection.count_documents(query)
            cursor = self.collection.find(query, {"_id": 0})
            records = list(
                cursor.sort([(sort_by, direction)])
                .skip(skip)
                .limit(page_size)
            )
            return {"records": records, "total": total}
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database search failed. Check the connection and filter."
            ) from exc

    def breed_summary(self, filter_type="reset", breed_search=None, limit=10):
        """Summarize matching records by breed with a MongoDB aggregation pipeline."""
        query = self.build_filter(filter_type, breed_search)
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 50:
            raise ValueError("Summary limit must be between 1 and 50.")

        pipeline = [
            {"$match": query},
            {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
            {"$sort": {"count": -1, "_id": 1}},
            {"$limit": limit},
            {"$project": {"_id": 0, "breed": "$_id", "count": 1}},
        ]
        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database summary failed. Check the connection and filter."
            ) from exc

    def create_indexes(self):
        """Create the compound index used by rescue-type filters."""
        try:
            rescue_index = self.collection.create_index(
                self.RESCUE_INDEX_KEYS,
                name=self.RESCUE_INDEX_NAME,
            )
            return [rescue_index]
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database index setup failed. Check database permissions."
            ) from exc

    def ensure_schema_and_indexes(self):
        """Install validation and indexes; run explicitly as a setup step."""
        options = {
            "validator": deepcopy(self.SCHEMA_VALIDATOR),
            "validationLevel": "moderate",
            "validationAction": "error",
        }
        try:
            collection_names = set(self.database.list_collection_names())
            if self.COLLECTION_NAME in collection_names:
                self.database.command({
                    "collMod": self.COLLECTION_NAME,
                    **options,
                })
            else:
                self.database.create_collection(self.COLLECTION_NAME, **options)
                self.collection = self.database[self.COLLECTION_NAME]
            return self.create_indexes()
        except PyMongoError as exc:
            raise DatabaseOperationError(
                "Database setup failed. Check collection permissions."
            ) from exc

    def close(self):
        """Close the MongoDB client."""
        if self.client is not None:
            self.client.close()

