import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from CRUD_Python_Module import (
    AnimalShelter,
    DatabaseOperationError,
    PyMongoError,
)


class FakeCursor:
    def __init__(self, records):
        self.records = list(records)
        self.sort_spec = None
        self.skip_count = 0
        self.limit_count = None
        self.hint_value = None

    def sort(self, specification):
        self.sort_spec = specification
        return self

    def skip(self, count):
        self.skip_count = count
        return self

    def limit(self, count):
        self.limit_count = count
        return self

    def hint(self, hint):
        self.hint_value = hint
        return self

    def __iter__(self):
        start = self.skip_count
        end = None if self.limit_count is None else start + self.limit_count
        return iter(self.records[start:end])


class FakeCollection:
    name = "animals"

    def __init__(self):
        self.records = [{"animal_id": "A-1", "breed": "Labrador"}]
        self.find_query = None
        self.projection = None
        self.cursor = None
        self.update_call = None
        self.delete_call = None
        self.pipeline = None
        self.fail_reads = False

    def find(self, query, projection=None):
        self.find_query = query
        self.projection = projection
        if self.fail_reads:
            raise PyMongoError("mongodb://username:secret@example.invalid")
        self.cursor = FakeCursor(self.records)
        return self.cursor

    def count_documents(self, query):
        return len(self.records)

    def aggregate(self, pipeline):
        self.pipeline = pipeline
        return [{"breed": "Labrador", "count": 12}]

    def update_one(self, query, update):
        self.update_call = (query, update)
        return type("Result", (), {"modified_count": 1})()

    def delete_one(self, query):
        self.delete_call = query
        return type("Result", (), {"deleted_count": 1})()

    def insert_one(self, document):
        self.inserted = document
        return type("Result", (), {"acknowledged": True})()

    def create_index(self, keys, name):
        return name


def make_shelter():
    shelter = AnimalShelter.__new__(AnimalShelter)
    shelter.collection = FakeCollection()
    shelter.client = None
    shelter.database = None
    return shelter


class AnimalShelterTests(unittest.TestCase):
    def setUp(self):
        self.shelter = make_shelter()

    def test_build_filter_escapes_user_search_as_literal_text(self):
        query = AnimalShelter.build_filter("reset", "Labrador.*")
        self.assertEqual(query["breed"]["$regex"], r"Labrador\.\*")
        self.assertEqual(query["breed"]["$options"], "i")

    def test_build_filter_uses_approved_rescue_criteria(self):
        query = AnimalShelter.build_filter("water")
        self.assertEqual(query["animal_type"], "Dog")
        self.assertEqual(query["sex_upon_outcome"], "Intact Female")
        self.assertEqual(
            query["age_upon_outcome_in_weeks"],
            {"$gte": 26, "$lte": 156},
        )
        self.assertEqual(len(query["$or"]), 3)

    def test_invalid_filter_and_long_search_are_rejected(self):
        with self.assertRaises(ValueError):
            AnimalShelter.build_filter("$where")
        with self.assertRaises(ValueError):
            AnimalShelter.build_filter("reset", "x" * 81)

    def test_search_page_applies_sort_and_server_side_pagination(self):
        records = [{"animal_id": f"A-{index}"} for index in range(60)]
        self.shelter.collection.records = records
        result = self.shelter.search_page(
            filter_type="water",
            page=2,
            page_size=20,
            sort_by="animal_id",
            descending=True,
        )
        self.assertEqual(result["total"], 60)
        self.assertEqual(result["records"], records[40:60])
        self.assertEqual(self.shelter.collection.cursor.sort_spec, [("animal_id", -1)])
        self.assertEqual(self.shelter.collection.cursor.skip_count, 40)
        self.assertEqual(self.shelter.collection.cursor.limit_count, 20)
        self.assertEqual(self.shelter.collection.projection, {"_id": 0})

    def test_search_page_rejects_unsafe_sort_and_page_size(self):
        with self.assertRaises(ValueError):
            self.shelter.search_page(sort_by="$where")
        with self.assertRaises(ValueError):
            self.shelter.search_page(page_size=1000)

    def test_read_is_bounded_and_rejects_operator_queries(self):
        rows = self.shelter.read({})
        self.assertEqual(rows, self.shelter.collection.records)
        self.assertEqual(self.shelter.collection.cursor.limit_count, 100)
        self.assertEqual(self.shelter.collection.projection, {"_id": 0})
        with self.assertRaises(ValueError):
            self.shelter.read({"$where": "true"})

    def test_empty_and_operator_based_write_filters_are_rejected(self):
        with self.assertRaises(ValueError):
            self.shelter.update({}, {"name": "Buddy"})
        with self.assertRaises(ValueError):
            self.shelter.delete({})
        with self.assertRaises(ValueError):
            self.shelter.delete({"animal_id": {"$ne": "A-1"}})

    def test_update_and_delete_are_single_record_operations(self):
        self.assertEqual(
            self.shelter.update({"animal_id": "A-1"}, {"name": "Buddy"}),
            1,
        )
        self.assertEqual(
            self.shelter.collection.update_call,
            ({"animal_id": "A-1"}, {"$set": {"name": "Buddy"}}),
        )
        self.assertEqual(self.shelter.delete({"animal_id": "A-1"}), 1)
        self.assertEqual(self.shelter.collection.delete_call, {"animal_id": "A-1"})

    def test_create_requires_a_valid_basic_record(self):
        with self.assertRaises(ValueError):
            self.shelter.create({"name": "Buddy"})
        self.assertTrue(self.shelter.create({
            "animal_id": "A-1",
            "animal_type": "Dog",
            "breed": "Labrador Retriever",
        }))

    def test_breed_summary_uses_mongodb_aggregation(self):
        summary = self.shelter.breed_summary("water", limit=5)
        self.assertEqual(summary[0]["breed"], "Labrador")
        self.assertEqual(self.shelter.collection.pipeline[0], {"$match": AnimalShelter.build_filter("water")})
        self.assertEqual(self.shelter.collection.pipeline[1]["$group"]["_id"], "$breed")
        self.assertEqual(self.shelter.collection.pipeline[-2], {"$limit": 5})

    def test_database_errors_do_not_expose_raw_connection_details(self):
        self.shelter.collection.fail_reads = True
        with self.assertRaises(DatabaseOperationError) as context:
            self.shelter.read({})
        self.assertNotIn("secret", str(context.exception))
        self.assertIn("Database read failed", str(context.exception))


if __name__ == "__main__":
    unittest.main()

