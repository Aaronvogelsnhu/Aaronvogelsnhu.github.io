from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        # Connection settings for local MongoDB instance
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        try:
            # Connect to MongoDB using the aacuser account
            self.client = MongoClient(
                'mongodb://%s:%s@%s:%d/?authSource=admin' %
                (username, password, HOST, PORT)
            )
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except PyMongoError as e:
            print("Connection error:", e)

    def create(self, data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except PyMongoError as e:
                print("Create error:", e)
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        if query is not None:
            try:
                data = self.collection.find(query)
                return list(data)
            except PyMongoError as e:
                print("Read error:", e)
                return []
        else:
            return []

    def update(self, query, new_values):
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except PyMongoError as e:
                print("Update error:", e)
                return 0
        else:
            return 0

    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except PyMongoError as e:
                print("Delete error:", e)
                return 0
        else:
            return 0